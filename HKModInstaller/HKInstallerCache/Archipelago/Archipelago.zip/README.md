# Archipelago.HollowKnight

A mod which enables Hollow Knight to act as an Archipelago client, enabling multiworld and randomization driven by the [Archipelago multigame multiworld system](https://archipelago.gg).

## Installing Archipelago.HollowKnight
### Installing with Lumafly
1. [Download Lumafly](https://themulhima.github.io/Lumafly?download).
2. Place Lumafly in a folder other than your Downloads folder and run it
    * If it does not detect your HK install directory, lead Lumafly to the correct directory.
    * Also, don’t pirate the game. >:(
3. Install and enable Archipelago.
    * There are several mods that are needed to for Archipelago to run. They are installed automatically.
    * Archipelago Map Mod is an in-game tracker for Archipelago. It is optional and can also be installed from Lumafly.
4. Start the game and ensure **Archipelago** appears in the top left corner of the main menu.

## Joining an Archipelago Session
1. Start the game after installing all necessary mods.
2. Create a **new save game.**
3. Select the **Archipelago** game mode from the mode selection screen.
4. Enter in the correct settings for your Archipelago server.
5. Hit **Start** to begin the game. The game will stall for a few seconds while it does all item placements.
6. The game will immediately drop you into the randomized game. So if you are waiting for a countdown then wait for it to lapse before hitting Start, or hit Start then pause the game once you're in it.

# Contributing
Contributions are welcome, all code is licensed under the MIT License. Please track your work within the repository if you are taking on a feature. This is done via GitHub Issues. If you are interesting in taking on an issue please comment on the issue to have it assigned to you. If you are looking to contribute something that isn't in the issues list then please submit an issue to describe what work you intend to take on.

Contribution guidelines:
* All issues should be labeled appropriately.
* All in-progress issues should have someone assigned to them.
* Pull Requests must have at least (and preferably exactly) one linked issue which they close out.
* Please use feature branches, especially if working in this repository (not a fork).
* Please match the style of the surrounding code. In particular:
    * Don't use `var`.
    * Use shorthand constructor syntax in declarations, and only in declarations (for example, `ArchipelagoRandomizer randomizer = new(slotData);`).
    * Always enclose the body of control flow statements (`if`, `foreach`, etc.) in braces, even for single-line bodies.

## Development Setup
Follow the instructions in the csproj file to create a LocalOverrides.targets file with your Hollow Knight installation path. If you use the Hollow Knight Modding Visual Studio extension (recommended), there is an item template to create this file for you automatically.

Post-build events will automatically package the mod for export **as well as install it in your HK installation.** When developing on the mod **do not install Archipelago through an installer.** Some installers, e.g. Lumafly, can pin the development version to prevent it from being replaced by the production version from the installer.

