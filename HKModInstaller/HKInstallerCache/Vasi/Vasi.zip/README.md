# Vasi

A small library for Hollow Knight mods. It packages a few utility classes which deal with FSMs, animating, reflection, versioning, etc.
